/**
 */
package ResearchProject;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Task</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ResearchProject.ResearchProjectPackage#getTask()
 * @model annotation="gmf.node label='name' figure='rectangle' color='200,200,255'"
 * @generated
 */
public interface Task extends NamedElement, TimedElement {
} // Task
