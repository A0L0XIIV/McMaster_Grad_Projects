/**
 */
package ResearchProject;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Deliverable</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ResearchProject.ResearchProjectPackage#getDeliverable()
 * @model annotation="gmf.node label='name' figure='rectangle' color='255,255,200'"
 * @generated
 */
public interface Deliverable extends NamedElement, TimedElement {
} // Deliverable
